/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */

 
public class Intellegometer {
    public static void main(String[] args) 
    {
        new START().setVisible(true);
        START start = new START();   // START is the name of the jFrame
        start.setVisible(true);
        
        try {
             for(int x = 0; x <=100; x++)
        {
        Thread.sleep(50);           //how long will it take to load
        
        START.loadbtn.setText(Integer.toString(x)+"%"); 
        START.loadbar.setValue(x);
    
        }
        } catch (Exception e) {
        }
        
        
    }

    
    
}
