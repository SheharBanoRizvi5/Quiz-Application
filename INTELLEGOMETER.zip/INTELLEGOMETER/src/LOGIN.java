
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */
public class LOGIN extends javax.swing.JFrame  {

    String username;
    String password;
       
            
    public LOGIN() {
        initComponents();
    }
    public void login(){
        
            this.username=username1Field.getText();
            this.password=password1Field.getText();
            boolean login=false;
            String [] use= new String[5];
            String [] pas=new String[5];
            System.out.print(username1Field.getText() +" "+password1Field.getText());
       
       try{
           FileReader fr=new FileReader("REGISTERATION Record.txt");
           BufferedReader br=new BufferedReader(fr);
           String line,user,pass;
           
           
           int i=0;
           while((line=br.readLine()) !=null){
                user=line.split("\t")[0];
                use[i]=user;
                pass=line.split("\t")[1];
                pas[i]=pass;
                i++;
                //line=br.readLine();
           }
           
            fr.close();
             for(int j=0;j<use.length;j++){
               System.out.print("\nuser["+j+"]="+use[j]+" ");
           }
           
           for(int j=0;j<pas.length;j++){
               System.out.print("\npass["+j+"]="+pas[j]+" ");
           }
           
              for(int k=0; k<4;k++)
           {
               if(username1.equals(use[k]) && (pas[k].equals(password1))){
                   System.out.println("****"+use[k]+"="+username1);
                   System.out.println("****"+pas[k]+"="+password1);
                   System.out.println("Successfully login");
                  QUESTION_1 Q1=new QUESTION_1();
                    Q1.setVisible(true);
                   
                   JOptionPane.showMessageDialog(null, "Successfully login");
                   break;
               }
               else
               {
                   System.out.println("****"+use[k]+"="+username1);
                   System.out.println("****"+pas[k]+"="+password1);
                   System.out.println("unSuccessfully login");
                   JOptionPane.showMessageDialog(null, "unSuccessfully login");
                  
               }
           }
            fr.close();
       }
       catch(Exception e){
           System.out.println("cannot open file");
       }
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        e = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        username1 = new javax.swing.JLabel();
        password1 = new javax.swing.JLabel();
        password1Field = new javax.swing.JPasswordField();
        login = new javax.swing.JButton();
        username1Field = new javax.swing.JTextField();
        Register = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        e.setBackground(new java.awt.Color(255, 102, 102));
        e.setForeground(new java.awt.Color(153, 153, 153));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Imprint MT Shadow", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("LOGIN TO INTELLEGOMETER");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 456, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        username1.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        username1.setForeground(new java.awt.Color(0, 102, 102));
        username1.setText("User Name");

        password1.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        password1.setForeground(new java.awt.Color(0, 102, 102));
        password1.setText("Password");

        password1Field.setBackground(new java.awt.Color(255, 102, 102));
        password1Field.setForeground(new java.awt.Color(102, 102, 102));
        password1Field.setText("jPasswordField1");
        password1Field.setBorder(null);

        login.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        login.setForeground(new java.awt.Color(0, 102, 102));
        login.setText("LOG IN");
        login.setBorder(null);
        login.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });

        username1Field.setBackground(new java.awt.Color(255, 102, 102));
        username1Field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                username1FieldActionPerformed(evt);
            }
        });

        Register.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        Register.setForeground(new java.awt.Color(0, 102, 102));
        Register.setText("REGISTER");
        Register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout eLayout = new javax.swing.GroupLayout(e);
        e.setLayout(eLayout);
        eLayout.setHorizontalGroup(
            eLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(eLayout.createSequentialGroup()
                .addGroup(eLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(eLayout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(eLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(password1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(password1Field)
                            .addComponent(username1)
                            .addComponent(username1Field)))
                    .addGroup(eLayout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(login, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(85, 85, 85)
                        .addComponent(Register)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        eLayout.setVerticalGroup(
            eLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(eLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(username1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(username1Field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23)
                .addComponent(password1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(password1Field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addGroup(eLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(login, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Register, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(64, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(e, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(e, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginActionPerformed
//             QUESTION_1 Q1=new QUESTION_1();
//        Q1.setVisible(true);
//       
//            this.dispose();
//        
      
        this.login();
        
       
           
//        
    }//GEN-LAST:event_loginActionPerformed

    private void username1FieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_username1FieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_username1FieldActionPerformed

    private void RegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterActionPerformed
        // TODO add your handling code here:
        REGISTERATION r = new REGISTERATION();
        r.setVisible(true);


    }//GEN-LAST:event_RegisterActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LOGIN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QUESTION_1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Register;
    private javax.swing.JPanel e;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton login;
    private javax.swing.JLabel password1;
    private javax.swing.JPasswordField password1Field;
    private javax.swing.JLabel username1;
    private javax.swing.JTextField username1Field;
    // End of variables declaration//GEN-END:variables
}
